package kdanzer.cipher;

public class Test {
	/**This is the main class starts the Gui
	 * @author Kalian Danzer
	 */
	public static void main(String[] args) { 
		@SuppressWarnings("unused")
		Controller c = new Controller();
	}
}
